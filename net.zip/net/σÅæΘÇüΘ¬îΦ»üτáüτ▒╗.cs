﻿using System;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace net{
    public class VertifiCode
    {
        string code = null;
        public string CreateRandomCode()
        {
            string allChar = "0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
            string[] allCharAry = allChar.Split(',');
            string randomCode = "";
            int temp = -1;
            Random rand = new Random();
            for (int i = 0; i < 6; i++)
            {
                if (temp != -1)
                {
                    rand = new Random(i * temp * ((int)DateTime.Now.Ticks));
                }
                int t = rand.Next(35);
                if (temp == t)
                {
                    return CreateRandomCode();
                }
                temp = t;
                randomCode += allCharAry[t];
            }
            return randomCode;
        }

        public void SendEmail(string toAddr, string code)
        {
            SmtpClient client = new SmtpClient("smtp.qq.com");
            client.EnableSsl = true;
            client.UseDefaultCredentials = false;
            client.Credentials = new System.Net.NetworkCredential("2994070158@qq.com", "hzopobwwhucxdeea");

            MailAddress from = new MailAddress("2994070158@qq.com", "服务器", Encoding.UTF8);//初始化发件人

            MailAddress to = new MailAddress(toAddr, "", Encoding.UTF8);//初始化收件人

            //设置邮件内容
            MailMessage message = new MailMessage(from, to);
            message.Body = code;
            message.BodyEncoding = Encoding.UTF8;
            message.Subject = "验证码";
            message.SubjectEncoding = Encoding.UTF8;
            message.IsBodyHtml = true;
            client.Send(message);
        }

        public bool sendCode(string toAddr)
        {
            code = this.CreateRandomCode();
            try
            {
                this.SendEmail(toAddr, code);
            }
            catch
            {
                return false;
            }
            return true;
        }
    }
}