﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Artech.WcfServices.Service.Interface;
using System.ServiceModel.Description;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            using (ChannelFactory<ICustomers> channelFactory = new ChannelFactory<ICustomers>("customerService"))
            {
                ICustomers proxy = channelFactory.CreateChannel();

            Console.WriteLine("所有用户列表：");
            Array.ForEach<Customer>(proxy.GetAll().ToArray(), customer => Console.WriteLine(customer));

            Console.WriteLine("\n添加一个新用户（003）：");
                proxy.Create(new Customer
                {
                    Id = "003",
                    Username = "Student3",
                    Password = "000000",
                    IdentifyCode = "WHU03"
                });
                Array.ForEach<Customer>(proxy.GetAll().ToArray(), customer => Console.WriteLine(customer));

                Console.WriteLine("\n修改用户（003）信息：");
                proxy.Update(new Customer
                {
                    Id = "003",
                    Username = "Student3",
                    Password = "010101",
                    IdentifyCode = "WHU03"
                });
                Array.ForEach<Customer>(proxy.GetAll().ToArray(), customer => Console.WriteLine(customer));
                Console.WriteLine("\n删除用户（003）信息：");

                proxy.Delete("003");
                Array.ForEach<Customer>(proxy.GetAll().ToArray(), customer => Console.WriteLine(customer));
            }

            Console.Read();
        }

    }
}
