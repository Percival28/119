﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Artech.WcfServices.Service.Interface;
using System.ServiceModel.Web;
using System.Net;

namespace Artech.WcfServices.Service
{
public class CustomersService : ICustomers
    {
    private static IList<Customer> customers = new List<Customer>
    {
        new Customer{ Id = "001", Username="Student1", Password="123456", IdentifyCode = "WHU01"},    
        new Customer{ Id = "001", Username="Student2", Password="333333", IdentifyCode = "WHU02"}
    };
    public Customer Get(string id)
    {
        Customer customer = customers.FirstOrDefault(e => e.Id == id);
        if (null == customer)
        {
            WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.NotFound;
        }
        return customer;
    }
    public void Create(Customer customer)
    {
        customers.Add(customer);
    }
    public void Update(Customer customer)
    {
        this.Delete(customer.Id);
        customers.Add(customer);
    }
    public void Delete(string id)
    {
        Customer customer = this.Get(id);
        if (null != customer)
        {
            customers.Remove(customer);
        }
    }
    public IEnumerable<Customer> GetAll()
    {
        return customers;
    }
}
}