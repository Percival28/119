﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel.Web;
using System.ServiceModel;

namespace Artech.WcfServices.Service.Interface
{
    [ServiceContract]
    public interface ICustomers
    {
        [WebGet(UriTemplate = "all")]
        IEnumerable<Customer> GetAll();

        [WebGet(UriTemplate = "{id}")]
        Customer Get(string id);

        [WebInvoke(UriTemplate = "/", Method = "POST")]
        void Create(Customer customer);

        [WebInvoke(UriTemplate = "/", Method = "PUT")]
        void Update(Customer customer);

        [WebInvoke(UriTemplate = "{id}", Method = "DELETE")]
        void Delete(string id);
    }

    [DataContract(Namespace = "http://www.artech.com/")]
    public class Customer
    {
        [DataMember]
        public string Id { get; set; }
        [DataMember]
        public string Username { get; set; }
        [DataMember]
        public string Password { get; set; }
        [DataMember]
        public string IdentifyCode { get; set; }

        public override string ToString()
        {
            return string.Format("ID: {0,-5}用户名: {1, -5}密码: {2, -4} 身份验证码: {3}", Id, Username, Password, IdentifyCode);
        }
    }
}
